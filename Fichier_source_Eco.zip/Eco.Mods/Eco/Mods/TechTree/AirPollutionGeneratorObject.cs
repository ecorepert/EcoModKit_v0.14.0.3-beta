﻿// Decompiled with JetBrains decompiler
// Type: Eco.Mods.TechTree.AirPollutionGeneratorObject
// Assembly: Eco.Mods, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8756697B-2B6C-4F56-B8E4-FD8F5F5392E7
// Assembly location: C:\Users\orfla\OneDrive\Documents\ecoserveur\EcoModKit_v0.14.0.3-beta\ReferenceAssemblies\Eco.Mods.dll
// XML documentation location: C:\Users\orfla\OneDrive\Documents\ecoserveur\EcoModKit_v0.14.0.3-beta\ReferenceAssemblies\Eco.Mods.xml

using Eco.Gameplay.Components;
using Eco.Gameplay.Components.Auth;
using Eco.Gameplay.Items;
using Eco.Gameplay.Objects;
using Eco.Shared.Localization;
using Eco.Shared.Serialization;
using System;

#nullable disable
namespace Eco.Mods.TechTree;

[Serialized]
[RequireComponent(typeof (OnOffComponent), null)]
[RequireComponent(typeof (AirPollutionComponent), null)]
[RequireComponent(typeof (PropertyAuthComponent), null)]
[RequireComponent(typeof (AirPollutionComponent), null)]
public class AirPollutionGeneratorObject : WorldObject, IRepresentsItem
{
  public override LocString DisplayName { get; }

  public virtual Type RepresentedItemType { get; }

  protected override void Initialize();

  protected override void PostInitialize();
}
