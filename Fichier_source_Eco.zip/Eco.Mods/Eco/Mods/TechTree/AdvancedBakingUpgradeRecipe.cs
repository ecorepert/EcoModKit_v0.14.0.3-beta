﻿// Decompiled with JetBrains decompiler
// Type: Eco.Mods.TechTree.AdvancedBakingUpgradeRecipe
// Assembly: Eco.Mods, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 8756697B-2B6C-4F56-B8E4-FD8F5F5392E7
// Assembly location: C:\Users\orfla\OneDrive\Documents\ecoserveur\EcoModKit_v0.14.0.3-beta\ReferenceAssemblies\Eco.Mods.dll
// XML documentation location: C:\Users\orfla\OneDrive\Documents\ecoserveur\EcoModKit_v0.14.0.3-beta\ReferenceAssemblies\Eco.Mods.xml

using Eco.Core.Items;
using Eco.Gameplay.Items.Recipes;
using Eco.Gameplay.Skills;

#nullable disable
namespace Eco.Mods.TechTree;

/// <summary>Auto-generated class. Don't modify it! All your changes will be wiped with next update! Use Mods* partial methods instead for customization.</summary>
/// <summary>
/// <para>Server side recipe definition for "AdvancedBakingUpgrade".</para>
/// <para>More information about RecipeFamily objects can be found at https://docs.play.eco/api/server/eco.gameplay/Eco.Gameplay.Items.RecipeFamily.html</para>
/// </summary>
/// <remarks>
/// This is an auto-generated class. Don't modify it! All your changes will be wiped with next update! Use Mods* partial methods instead for customization.
/// If you wish to modify this class, please create a new partial class or follow the instructions in the "UserCode" folder to override the entire file.
/// </remarks>
[RequiresSkill(typeof (AdvancedBakingSkill), 2)]
[Ecopedia("Upgrade Modules", "Specialty Upgrades", false, true, "Advanced Baking Upgrade Item")]
public class AdvancedBakingUpgradeRecipe : RecipeFamily
{
}
